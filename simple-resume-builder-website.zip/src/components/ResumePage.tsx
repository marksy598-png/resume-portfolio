import { useState } from 'react';
import { ResumeForm } from './ResumeForm';
import { ResumePreview } from './ResumePreview';
import { initialResumeData, ResumeData } from '../types';
import { Printer, FileDown, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const ResumePage = () => {
  const [resumeData, setResumeData] = useState<ResumeData>(initialResumeData);
  const navigate = useNavigate();

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-900">
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <button onClick={() => navigate('/')} className="p-2 hover:bg-slate-100 rounded-full transition-colors" title="Back to Home">
                <ArrowLeft className="w-5 h-5 text-slate-600" />
             </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                R
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
                Resume Builder
              </span>
            </div>
          </div>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-sm hover:shadow-md"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">Print / Save as PDF</span>
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Editor Section */}
          <div className="space-y-6 print:hidden">
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-blue-800 text-sm">
              <h4 className="font-semibold flex items-center gap-2">
                <FileDown className="w-4 h-4" />
                How to save as PDF?
              </h4>
              <p className="mt-1 ml-6">
                Click the <strong>Print / Save as PDF</strong> button and select "Save as PDF" as the destination in the print dialog.
              </p>
            </div>
            
            <ResumeForm data={resumeData} updateData={setResumeData} mode="resume" />
          </div>

          {/* Preview Section */}
          <div className="lg:sticky lg:top-24 h-fit print:w-full print:absolute print:top-0 print:left-0 print:m-0">
            <div className="mb-4 lg:hidden print:hidden">
              <h2 className="text-xl font-bold text-slate-800">Preview</h2>
            </div>
            <div className="print:w-full">
              <ResumePreview data={resumeData} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
