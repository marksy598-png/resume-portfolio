import React from 'react';
import { ResumeData, Education, Experience, Project, SocialLink, TemplateType, PortfolioTemplate } from '../types';
import { Plus, Trash2, User, Briefcase, GraduationCap, Award, FolderGit2, Globe, FileText, Layout, Palette, ChevronDown, ChevronUp } from 'lucide-react';

interface ResumeFormProps {
  data: ResumeData;
  updateData: (newData: ResumeData) => void;
  mode?: 'resume' | 'portfolio';
}

const SectionHeader = ({ icon: Icon, title, isOpen, toggle }: { icon: any, title: string, isOpen: boolean, toggle: () => void }) => (
  <button 
    onClick={toggle}
    className="w-full flex items-center justify-between p-4 bg-slate-50 hover:bg-slate-100 transition-colors border-b border-slate-200 first:rounded-t-lg last:border-b-0"
  >
    <div className="flex items-center gap-2 font-semibold text-slate-700">
      <Icon className="w-5 h-5 text-blue-600" />
      {title}
    </div>
    {isOpen ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
  </button>
);

export const ResumeForm: React.FC<ResumeFormProps> = ({ data, updateData, mode = 'resume' }) => {
  const [openSections, setOpenSections] = React.useState<Record<string, boolean>>({
    design: true,
    personal: true,
  });

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name.startsWith('pd_')) {
      const field = name.replace('pd_', '');
      updateData({
        ...data,
        personalDetails: { ...data.personalDetails, [field]: value }
      });
    } else {
      updateData({ ...data, [name]: value });
    }
  };

  // Education Helpers
  const addEducation = () => updateData({ ...data, educations: [...data.educations, { id: Date.now().toString(), degree: "", institution: "", year: "", grade: "" }] });
  const removeEducation = (id: string) => updateData({ ...data, educations: data.educations.filter(edu => edu.id !== id) });
  const updateEducation = (id: string, field: keyof Education, value: string) => updateData({ ...data, educations: data.educations.map(edu => edu.id === id ? { ...edu, [field]: value } : edu) });

  // Experience Helpers
  const addExperience = () => updateData({ ...data, experiences: [...data.experiences, { id: Date.now().toString(), role: "", company: "", duration: "", description: "" }] });
  const removeExperience = (id: string) => updateData({ ...data, experiences: data.experiences.filter(exp => exp.id !== id) });
  const updateExperience = (id: string, field: keyof Experience, value: string) => updateData({ ...data, experiences: data.experiences.map(exp => exp.id === id ? { ...exp, [field]: value } : exp) });

  // Project Helpers
  const addProject = () => updateData({ ...data, projects: [...data.projects, { id: Date.now().toString(), title: "", description: "", link: "", techStack: "" }] });
  const removeProject = (id: string) => updateData({ ...data, projects: data.projects.filter(proj => proj.id !== id) });
  const updateProject = (id: string, field: keyof Project, value: string) => updateData({ ...data, projects: data.projects.map(proj => proj.id === id ? { ...proj, [field]: value } : proj) });

  // Social Link Helpers
  const addSocial = () => updateData({ ...data, socialLinks: [...data.socialLinks, { id: Date.now().toString(), platform: "", url: "" }] });
  const removeSocial = (id: string) => updateData({ ...data, socialLinks: data.socialLinks.filter(soc => soc.id !== id) });
  const updateSocial = (id: string, field: keyof SocialLink, value: string) => updateData({ ...data, socialLinks: data.socialLinks.map(soc => soc.id === id ? { ...soc, [field]: value } : soc) });

  const resumeTemplates: {id: TemplateType, name: string}[] = [
    { id: 'classic', name: 'Classic Resume' },
    { id: 'modern', name: 'Modern Professional' },
    { id: 'minimalist', name: 'Clean Minimalist' },
    { id: 'portfolio', name: 'Web Portfolio' },
  ];

  const portfolioTemplates: {id: PortfolioTemplate, name: string}[] = [
    { id: 'divine_scroll', name: 'Divine Scroll' },
    { id: 'royal_grid', name: 'Royal Grid' },
    { id: 'modern_saffron', name: 'Modern Saffron' },
  ];

  const colors = [
    { name: 'Saffron', value: '#FF9933' },
    { name: 'Gold', value: '#FFD700' },
    { name: 'Maroon', value: '#800000' },
    { name: 'Blue', value: '#2563eb' },
    { name: 'Indigo', value: '#4f46e5' },
    { name: 'Purple', value: '#7c3aed' },
    { name: 'Pink', value: '#db2777' },
    { name: 'Red', value: '#dc2626' },
    { name: 'Orange', value: '#ea580c' },
    { name: 'Green', value: '#16a34a' },
    { name: 'Teal', value: '#0d9488' },
    { name: 'Black', value: '#1f2937' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-200 bg-slate-50">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <FileText className="w-5 h-5" /> Editor
        </h2>
      </div>

      <div className="divide-y divide-slate-200">
        
        {/* Design Settings */}
        <div className="bg-white">
          <SectionHeader icon={Layout} title="Template & Design" isOpen={openSections.design} toggle={() => toggleSection('design')} />
          {openSections.design && (
            <div className="p-4 space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Choose Template</label>
                <div className="grid grid-cols-2 gap-3">
                  {mode === 'resume' ? (
                    resumeTemplates.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => updateData({ ...data, template: t.id })}
                        className={`p-3 text-sm rounded-lg border-2 text-left transition-all ${
                          data.template === t.id 
                            ? 'border-orange-500 bg-orange-50 text-orange-700 font-medium' 
                            : 'border-slate-200 hover:border-slate-300 text-slate-600'
                        }`}
                      >
                        {t.name}
                      </button>
                    ))
                  ) : (
                    portfolioTemplates.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => updateData({ ...data, portfolioTemplate: t.id })}
                        className={`p-3 text-sm rounded-lg border-2 text-left transition-all ${
                          data.portfolioTemplate === t.id 
                            ? 'border-orange-500 bg-orange-50 text-orange-700 font-medium' 
                            : 'border-slate-200 hover:border-slate-300 text-slate-600'
                        }`}
                      >
                        {t.name}
                      </button>
                    ))
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                  <Palette className="w-4 h-4" /> Accent Color
                </label>
                <div className="flex flex-wrap gap-3">
                  {colors.map((c) => (
                    <button
                      key={c.value}
                      onClick={() => updateData({ ...data, themeColor: c.value })}
                      className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${
                        data.themeColor === c.value ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-300' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c.value }}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Personal Info */}
        <div className="bg-white">
          <SectionHeader icon={User} title="Personal Details" isOpen={openSections.personal} toggle={() => toggleSection('personal')} />
          {openSections.personal && (
            <div className="p-4 grid grid-cols-1 gap-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" name="fullName" placeholder="Full Name" value={data.fullName} onChange={handleChange} className="input-field" />
                <input type="text" name="title" placeholder="Job Title (e.g. Frontend Dev)" value={data.title} onChange={handleChange} className="input-field" />
                <input type="text" name="email" placeholder="Email" value={data.email} onChange={handleChange} className="input-field" />
                <input type="text" name="phone" placeholder="Phone" value={data.phone} onChange={handleChange} className="input-field" />
                <input type="text" name="city" placeholder="City, Country" value={data.city} onChange={handleChange} className="input-field" />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Social Links</label>
                {data.socialLinks.map((soc) => (
                  <div key={soc.id} className="flex gap-2">
                    <input placeholder="Platform (e.g. LinkedIn)" value={soc.platform} onChange={(e) => updateSocial(soc.id, 'platform', e.target.value)} className="input-field w-1/3" />
                    <input placeholder="URL" value={soc.url} onChange={(e) => updateSocial(soc.id, 'url', e.target.value)} className="input-field flex-1" />
                    <button onClick={() => removeSocial(soc.id)} className="text-red-500 hover:text-red-700 p-2"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                <button onClick={addSocial} className="text-sm text-blue-600 font-medium flex items-center gap-1"><Plus className="w-3 h-3" /> Add Link</button>
              </div>

              <textarea name="careerObjective" placeholder="Professional Summary / About Me" value={data.careerObjective} onChange={handleChange} className="input-field h-24" />
            </div>
          )}
        </div>

        {/* Experience */}
        <div className="bg-white">
          <SectionHeader icon={Briefcase} title="Experience" isOpen={openSections.experience} toggle={() => toggleSection('experience')} />
          {openSections.experience && (
            <div className="p-4 space-y-4">
              {data.experiences.map((exp) => (
                <div key={exp.id} className="p-4 bg-slate-50 rounded border border-slate-200 relative">
                  <button onClick={() => removeExperience(exp.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <input placeholder="Role" value={exp.role} onChange={(e) => updateExperience(exp.id, 'role', e.target.value)} className="input-field" />
                      <input placeholder="Company" value={exp.company} onChange={(e) => updateExperience(exp.id, 'company', e.target.value)} className="input-field" />
                      <input placeholder="Duration" value={exp.duration} onChange={(e) => updateExperience(exp.id, 'duration', e.target.value)} className="input-field" />
                    </div>
                    <textarea placeholder="Description" value={exp.description} onChange={(e) => updateExperience(exp.id, 'description', e.target.value)} className="input-field h-20" />
                  </div>
                </div>
              ))}
              <button onClick={addExperience} className="w-full py-2 border-2 border-dashed border-slate-300 rounded text-slate-500 hover:border-blue-400 hover:text-blue-500 font-medium">+ Add Experience</button>
            </div>
          )}
        </div>

        {/* Projects */}
        <div className="bg-white">
          <SectionHeader icon={FolderGit2} title="Projects" isOpen={openSections.projects} toggle={() => toggleSection('projects')} />
          {openSections.projects && (
            <div className="p-4 space-y-4">
              {data.projects.map((proj) => (
                <div key={proj.id} className="p-4 bg-slate-50 rounded border border-slate-200 relative">
                  <button onClick={() => removeProject(proj.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                  <div className="space-y-3">
                    <input placeholder="Project Title" value={proj.title} onChange={(e) => updateProject(proj.id, 'title', e.target.value)} className="input-field font-medium" />
                    <div className="grid grid-cols-2 gap-3">
                      <input placeholder="Live Link / Repo URL" value={proj.link} onChange={(e) => updateProject(proj.id, 'link', e.target.value)} className="input-field" />
                      <input placeholder="Tech Stack (e.g. React, Node)" value={proj.techStack} onChange={(e) => updateProject(proj.id, 'techStack', e.target.value)} className="input-field" />
                    </div>
                    <textarea placeholder="Description" value={proj.description} onChange={(e) => updateProject(proj.id, 'description', e.target.value)} className="input-field h-20" />
                  </div>
                </div>
              ))}
              <button onClick={addProject} className="w-full py-2 border-2 border-dashed border-slate-300 rounded text-slate-500 hover:border-blue-400 hover:text-blue-500 font-medium">+ Add Project</button>
            </div>
          )}
        </div>

        {/* Education */}
        <div className="bg-white">
          <SectionHeader icon={GraduationCap} title="Education" isOpen={openSections.education} toggle={() => toggleSection('education')} />
          {openSections.education && (
            <div className="p-4 space-y-4">
              {data.educations.map((edu) => (
                <div key={edu.id} className="p-4 bg-slate-50 rounded border border-slate-200 relative">
                  <button onClick={() => removeEducation(edu.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                  <div className="grid grid-cols-2 gap-3">
                    <input placeholder="Degree" value={edu.degree} onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)} className="input-field" />
                    <input placeholder="Institution" value={edu.institution} onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)} className="input-field" />
                    <input placeholder="Year" value={edu.year} onChange={(e) => updateEducation(edu.id, 'year', e.target.value)} className="input-field" />
                    <input placeholder="Grade" value={edu.grade} onChange={(e) => updateEducation(edu.id, 'grade', e.target.value)} className="input-field" />
                  </div>
                </div>
              ))}
              <button onClick={addEducation} className="w-full py-2 border-2 border-dashed border-slate-300 rounded text-slate-500 hover:border-blue-400 hover:text-blue-500 font-medium">+ Add Education</button>
            </div>
          )}
        </div>

        {/* Skills & Others */}
        <div className="bg-white">
          <SectionHeader icon={Award} title="Skills & Certifications" isOpen={openSections.skills} toggle={() => toggleSection('skills')} />
          {openSections.skills && (
            <div className="p-4 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Skills</label>
                <textarea name="skills" placeholder="Skills (comma separated)" value={data.skills} onChange={handleChange} className="input-field h-20" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Certifications</label>
                <textarea name="certifications" placeholder="Certifications (one per line)" value={data.certifications} onChange={handleChange} className="input-field h-20" />
              </div>
               <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Achievements</label>
                <textarea name="achievements" placeholder="Achievements (one per line)" value={data.achievements} onChange={handleChange} className="input-field h-20" />
              </div>
            </div>
          )}
        </div>

        {/* Other Details */}
         <div className="bg-white">
          <SectionHeader icon={Globe} title="Other Details" isOpen={openSections.others} toggle={() => toggleSection('others')} />
          {openSections.others && (
            <div className="p-4 space-y-4">
               <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Languages</label>
                <input name="languages" placeholder="Languages Known" value={data.languages} onChange={handleChange} className="input-field" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input name="pd_dob" placeholder="Date of Birth" value={data.personalDetails.dob} onChange={handleChange} className="input-field" />
                <input name="pd_gender" placeholder="Gender" value={data.personalDetails.gender} onChange={handleChange} className="input-field" />
                <input name="pd_nationality" placeholder="Nationality" value={data.personalDetails.nationality} onChange={handleChange} className="input-field" />
                <input name="pd_maritalStatus" placeholder="Marital Status" value={data.personalDetails.maritalStatus} onChange={handleChange} className="input-field" />
              </div>
            </div>
          )}
        </div>

      </div>
      <style>{`
        .input-field {
          width: 100%;
          padding: 0.5rem 0.75rem;
          border: 1px solid #e2e8f0;
          border-radius: 0.375rem;
          font-size: 0.875rem;
          outline: none;
          transition: all 0.2s;
        }
        .input-field:focus {
          border-color: #3b82f6;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
        }
      `}</style>
    </div>
  );
};
