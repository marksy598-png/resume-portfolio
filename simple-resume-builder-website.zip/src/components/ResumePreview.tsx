import React from 'react';
import { ResumeData } from '../types';
import { ClassicTemplate } from './templates/ClassicTemplate';
import { ModernTemplate } from './templates/ModernTemplate';
import { MinimalistTemplate } from './templates/MinimalistTemplate';
import { PortfolioTemplate } from './templates/PortfolioTemplate';

interface ResumePreviewProps {
  data: ResumeData;
}

export const ResumePreview: React.FC<ResumePreviewProps> = ({ data }) => {
  const getTemplate = () => {
    switch (data.template) {
      case 'modern':
        return <ModernTemplate data={data} />;
      case 'minimalist':
        return <MinimalistTemplate data={data} />;
      case 'portfolio':
        return <PortfolioTemplate data={data} />;
      case 'classic':
      default:
        return <ClassicTemplate data={data} />;
    }
  };

  return (
    <div id="resume-preview" className="shadow-2xl print:shadow-none w-full max-w-[210mm] mx-auto overflow-hidden print:w-full print:max-w-none">
      {getTemplate()}
    </div>
  );
};
