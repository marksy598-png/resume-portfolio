import React from 'react';
import { ResumeData } from '../../types';
import { Phone, Mail, MapPin, Globe } from 'lucide-react';

export const ModernTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  const { themeColor } = data;

  return (
    <div className="bg-white min-h-[1100px] flex">
      {/* Sidebar */}
      <div className="w-1/3 text-white p-8 flex flex-col gap-6" style={{ backgroundColor: themeColor }}>
        <div className="text-center mb-6">
          <div className="w-32 h-32 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl font-bold border-4 border-white/30">
            {data.fullName.charAt(0)}
          </div>
          <h2 className="text-xl font-bold mb-1">{data.fullName}</h2>
          <p className="text-white/80 font-medium">{data.title}</p>
        </div>

        <div className="space-y-4 text-sm">
          <h3 className="font-bold border-b border-white/30 pb-2 uppercase tracking-wider">Contact</h3>
          <div className="space-y-3">
            {data.phone && <div className="flex items-center gap-2"><Phone className="w-4 h-4" /> <span>{data.phone}</span></div>}
            {data.email && <div className="flex items-center gap-2 break-all"><Mail className="w-4 h-4" /> <span>{data.email}</span></div>}
            {data.city && <div className="flex items-center gap-2"><MapPin className="w-4 h-4" /> <span>{data.city}</span></div>}
            {data.socialLinks.map(soc => (
              <div key={soc.id} className="flex items-center gap-2">
                <Globe className="w-4 h-4" /> <a href={soc.url} className="underline text-white/90">{soc.platform}</a>
              </div>
            ))}
          </div>
        </div>

        {data.skills && (
          <div className="space-y-4 text-sm">
            <h3 className="font-bold border-b border-white/30 pb-2 uppercase tracking-wider">Skills</h3>
            <div className="flex flex-wrap gap-2">
              {data.skills.split(',').map((skill, i) => (
                <span key={i} className="bg-white/20 px-2 py-1 rounded text-xs">{skill.trim()}</span>
              ))}
            </div>
          </div>
        )}

        {data.languages && (
           <div className="space-y-4 text-sm">
            <h3 className="font-bold border-b border-white/30 pb-2 uppercase tracking-wider">Languages</h3>
            <p className="text-white/90">{data.languages}</p>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="w-2/3 p-8 space-y-8">
        {data.careerObjective && (
          <section>
            <h2 className="text-xl font-bold uppercase mb-4 flex items-center gap-2" style={{ color: themeColor }}>Profile</h2>
            <p className="text-slate-600 leading-relaxed text-sm">{data.careerObjective}</p>
          </section>
        )}

        {data.experiences.length > 0 && (
          <section>
            <h2 className="text-xl font-bold uppercase mb-4 flex items-center gap-2" style={{ color: themeColor }}>Experience</h2>
            <div className="space-y-6 border-l-2 pl-6" style={{ borderColor: themeColor + '40' }}>
              {data.experiences.map((exp) => (
                <div key={exp.id} className="relative">
                  <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full border-2 bg-white" style={{ borderColor: themeColor }}></div>
                  <h3 className="font-bold text-slate-800">{exp.role}</h3>
                  <div className="flex justify-between text-sm text-slate-500 mb-2">
                    <span className="font-semibold">{exp.company}</span>
                    <span>{exp.duration}</span>
                  </div>
                  <p className="text-slate-600 text-sm whitespace-pre-line">{exp.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.projects.length > 0 && (
          <section>
            <h2 className="text-xl font-bold uppercase mb-4 flex items-center gap-2" style={{ color: themeColor }}>Projects</h2>
            <div className="grid grid-cols-1 gap-4">
              {data.projects.map((proj) => (
                <div key={proj.id} className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-slate-800">{proj.title}</h3>
                    {proj.link && <a href={proj.link} className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700 hover:bg-blue-200">View</a>}
                  </div>
                  {proj.techStack && <div className="text-xs font-mono text-slate-500 mb-2">{proj.techStack}</div>}
                  <p className="text-slate-600 text-sm">{proj.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.educations.length > 0 && (
          <section>
            <h2 className="text-xl font-bold uppercase mb-4 flex items-center gap-2" style={{ color: themeColor }}>Education</h2>
            <div className="space-y-4">
              {data.educations.map((edu) => (
                <div key={edu.id} className="flex justify-between items-center text-sm border-b border-slate-100 pb-2 last:border-0">
                  <div>
                    <div className="font-bold text-slate-800">{edu.degree}</div>
                    <div className="text-slate-600">{edu.institution}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-slate-800">{edu.year}</div>
                    <div className="text-slate-500 text-xs">Grade: {edu.grade}</div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
