import React, { useRef } from 'react';
import { ResumeData } from '../types';
import { Mail, Phone, MapPin, Globe, ExternalLink, Star, Award, BookOpen } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface PortfolioPreviewProps {
  data: ResumeData;
}

export const PortfolioPreview: React.FC<PortfolioPreviewProps> = ({ data }) => {
  const componentRef = useRef<HTMLDivElement>(null);

  const handlePrint = async () => {
    if (componentRef.current) {
      const canvas = await html2canvas(componentRef.current, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [canvas.width, canvas.height]
      });
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save('portfolio.pdf');
    }
  };

  const {
    portfolioTemplate,
    themeColor,
    fullName,
    title,
    phone,
    email,
    city,
    socialLinks,
    careerObjective,
    skills,
    educations,
    projects,
    experiences,
    languages
  } = data;

  // Color utility removed as unused

  /* --- TEMPLATE 1: DIVINE SCROLL --- */
  if (portfolioTemplate === 'divine_scroll') {
    return (
      <div className="h-full flex flex-col">
        <div className="flex justify-end mb-4 gap-2 no-print">
          <button onClick={handlePrint} className="bg-orange-600 text-white px-4 py-2 rounded shadow hover:bg-orange-700 transition">
            Download Scroll PDF
          </button>
        </div>
        <div ref={componentRef} className="bg-[#fdfbf7] min-h-[1100px] p-12 shadow-2xl relative overflow-hidden font-serif text-amber-900 border-y-8 border-double border-orange-200">
           {/* Decorative Corners */}
           <div className="absolute top-0 left-0 w-32 h-32 border-t-4 border-l-4 border-orange-300 rounded-tl-3xl m-4 opacity-50"></div>
           <div className="absolute top-0 right-0 w-32 h-32 border-t-4 border-r-4 border-orange-300 rounded-tr-3xl m-4 opacity-50"></div>
           <div className="absolute bottom-0 left-0 w-32 h-32 border-b-4 border-l-4 border-orange-300 rounded-bl-3xl m-4 opacity-50"></div>
           <div className="absolute bottom-0 right-0 w-32 h-32 border-b-4 border-r-4 border-orange-300 rounded-br-3xl m-4 opacity-50"></div>

           <header className="text-center mb-16 relative z-10">
             <div className="mb-4 text-orange-500 mx-auto w-16 h-16 flex items-center justify-center border-2 border-orange-300 rounded-full rotate-45">
               <div className="-rotate-45"><Star size={32} /></div>
             </div>
             <h1 className="text-6xl font-bold tracking-wider mb-2" style={{ color: themeColor }}>{fullName}</h1>
             <p className="text-2xl italic text-amber-800/80 mb-6">{title}</p>
             <div className="flex justify-center flex-wrap gap-6 text-amber-900/70 border-t border-b border-orange-200 py-4 max-w-2xl mx-auto">
               {email && <span className="flex items-center gap-2"><Mail size={16} /> {email}</span>}
               {phone && <span className="flex items-center gap-2"><Phone size={16} /> {phone}</span>}
               {city && <span className="flex items-center gap-2"><MapPin size={16} /> {city}</span>}
             </div>
           </header>

           <div className="max-w-4xl mx-auto space-y-16 relative z-10">
             {careerObjective && (
               <section className="text-center">
                 <p className="text-xl leading-relaxed italic px-8">"{careerObjective}"</p>
               </section>
             )}

             <section>
               <h2 className="text-3xl font-bold text-center mb-8 flex items-center justify-center gap-4">
                 <span className="h-px bg-orange-300 w-12"></span>
                 <span style={{ color: themeColor }}>Projects & Works</span>
                 <span className="h-px bg-orange-300 w-12"></span>
               </h2>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 {projects.map(proj => (
                   <div key={proj.id} className="bg-orange-50/50 p-6 rounded-lg border border-orange-100 hover:shadow-lg transition-shadow">
                     <h3 className="text-xl font-bold mb-2 text-amber-900">{proj.title}</h3>
                     <p className="text-amber-800/80 mb-4">{proj.description}</p>
                     {proj.techStack && <p className="text-sm font-semibold text-orange-600 mb-2">stack: {proj.techStack}</p>}
                     {proj.link && (
                       <a href={proj.link} className="inline-flex items-center gap-1 text-sm text-amber-700 hover:text-orange-600 underline">
                         View Project <ExternalLink size={12} />
                       </a>
                     )}
                   </div>
                 ))}
               </div>
             </section>

             <div className="grid md:grid-cols-2 gap-12">
               <section>
                 <h2 className="text-2xl font-bold mb-6 text-center" style={{ color: themeColor }}>Experience</h2>
                 <div className="space-y-6 border-l-2 border-orange-200 pl-6 ml-4">
                   {experiences.map(exp => (
                     <div key={exp.id} className="relative">
                       <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-orange-100 border-2 border-orange-400"></div>
                       <h3 className="text-lg font-bold text-amber-900">{exp.role}</h3>
                       <div className="text-orange-600 font-medium text-sm mb-2">{exp.company} • {exp.duration}</div>
                       <p className="text-amber-800/80 text-sm">{exp.description}</p>
                     </div>
                   ))}
                 </div>
               </section>

               <section>
                 <h2 className="text-2xl font-bold mb-6 text-center" style={{ color: themeColor }}>Expertise</h2>
                 <div className="bg-white/60 p-6 rounded-xl border border-orange-100">
                    <div className="flex flex-wrap gap-2">
                      {skills.split(',').map((skill, i) => (
                        <span key={i} className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm border border-orange-200">
                          {skill.trim()}
                        </span>
                      ))}
                    </div>
                 </div>
               </section>
             </div>
           </div>
           
           <div className="mt-20 text-center opacity-40">
             <div className="text-4xl">❖</div>
           </div>
        </div>
      </div>
    );
  }

  /* --- TEMPLATE 2: ROYAL GRID --- */
  if (portfolioTemplate === 'royal_grid') {
    return (
      <div className="h-full flex flex-col">
        <div className="flex justify-end mb-4 gap-2 no-print">
          <button onClick={handlePrint} className="bg-gray-900 text-white px-4 py-2 rounded shadow hover:bg-black transition">
            Download PDF
          </button>
        </div>
        <div ref={componentRef} className="bg-slate-900 min-h-[1100px] text-slate-100 font-sans p-8">
           <header className="border-b-4 border-yellow-500 pb-8 mb-12 flex flex-col md:flex-row justify-between items-end gap-6">
             <div>
               <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-600">
                 {fullName}
               </h1>
               <p className="text-2xl text-yellow-500 font-light tracking-widest mt-2">{title.toUpperCase()}</p>
             </div>
             <div className="text-right text-slate-400 text-sm space-y-1">
               <p>{email}</p>
               <p>{phone}</p>
               <p>{city}</p>
             </div>
           </header>

           <div className="grid grid-cols-12 gap-8">
             {/* Left Column - Details */}
             <div className="col-span-12 md:col-span-4 space-y-12">
               <section>
                 <h3 className="text-yellow-500 font-bold uppercase tracking-wider mb-4 border-l-4 border-yellow-500 pl-3">About</h3>
                 <p className="text-slate-300 leading-relaxed">{careerObjective}</p>
               </section>

               <section>
                 <h3 className="text-yellow-500 font-bold uppercase tracking-wider mb-4 border-l-4 border-yellow-500 pl-3">Skills</h3>
                 <div className="flex flex-wrap gap-2">
                   {skills.split(',').map((s, i) => (
                     <span key={i} className="bg-slate-800 text-yellow-400 px-3 py-1 text-sm border border-slate-700">
                       {s.trim()}
                     </span>
                   ))}
                 </div>
               </section>

               <section>
                 <h3 className="text-yellow-500 font-bold uppercase tracking-wider mb-4 border-l-4 border-yellow-500 pl-3">Education</h3>
                 <div className="space-y-4">
                   {educations.map(edu => (
                     <div key={edu.id}>
                       <div className="font-bold text-white">{edu.degree}</div>
                       <div className="text-sm text-slate-400">{edu.institution}</div>
                       <div className="text-xs text-yellow-500/80">{edu.year}</div>
                     </div>
                   ))}
                 </div>
               </section>
             </div>

             {/* Right Column - Projects & Exp */}
             <div className="col-span-12 md:col-span-8 space-y-12">
               <section>
                 <h3 className="text-yellow-500 font-bold uppercase tracking-wider mb-6 flex items-center gap-2">
                   <BookOpen size={20} /> Featured Projects
                 </h3>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   {projects.map(proj => (
                     <div key={proj.id} className="bg-slate-800 p-6 border border-slate-700 hover:border-yellow-500 transition-colors group">
                       <h4 className="text-xl font-bold text-white mb-2 group-hover:text-yellow-400">{proj.title}</h4>
                       <p className="text-slate-400 text-sm mb-4 line-clamp-3">{proj.description}</p>
                       <div className="flex justify-between items-center mt-auto">
                         <span className="text-xs text-slate-500 font-mono">{proj.techStack}</span>
                         {proj.link && <ExternalLink size={16} className="text-yellow-500" />}
                       </div>
                     </div>
                   ))}
                 </div>
               </section>

               <section>
                 <h3 className="text-yellow-500 font-bold uppercase tracking-wider mb-6 flex items-center gap-2">
                   <Award size={20} /> Experience
                 </h3>
                 <div className="space-y-6">
                   {experiences.map(exp => (
                     <div key={exp.id} className="bg-slate-800/50 p-6 rounded-r-xl border-l-4 border-slate-600 hover:border-yellow-500 transition-all">
                       <div className="flex justify-between items-start mb-2">
                         <h4 className="text-lg font-bold text-white">{exp.role}</h4>
                         <span className="text-xs bg-slate-700 text-yellow-400 px-2 py-1 rounded">{exp.duration}</span>
                       </div>
                       <div className="text-slate-400 text-sm mb-3">{exp.company}</div>
                       <p className="text-slate-300 text-sm">{exp.description}</p>
                     </div>
                   ))}
                 </div>
               </section>
             </div>
           </div>
        </div>
      </div>
    );
  }

  /* --- TEMPLATE 3: MODERN SAFFRON --- */
  return (
    <div className="h-full flex flex-col">
       <div className="flex justify-end mb-4 gap-2 no-print">
          <button onClick={handlePrint} className="bg-orange-500 text-white px-4 py-2 rounded shadow hover:bg-orange-600 transition">
            Download PDF
          </button>
        </div>
       <div ref={componentRef} className="bg-white min-h-[1100px] p-8 md:p-16 text-slate-800 relative">
          <div className="absolute top-0 right-0 w-64 h-full bg-orange-50/50 -z-0"></div>
          
          <div className="relative z-10 grid grid-cols-3 gap-12">
            
            {/* Left Main Content */}
            <div className="col-span-2 space-y-10">
              <header className="space-y-4">
                <h1 className="text-6xl font-light text-slate-900 tracking-tight">{fullName}</h1>
                <p className="text-2xl text-orange-600 font-medium">{title}</p>
                <p className="text-lg text-slate-600 leading-relaxed max-w-lg">
                  {careerObjective}
                </p>
              </header>

              <section>
                <h3 className="text-lg font-bold text-slate-900 uppercase tracking-widest border-b-2 border-orange-200 pb-2 mb-6">
                  Selected Works
                </h3>
                <div className="space-y-8">
                  {projects.map(proj => (
                    <div key={proj.id} className="group">
                      <div className="flex items-baseline justify-between mb-2">
                        <h4 className="text-xl font-bold text-slate-800 group-hover:text-orange-600 transition-colors">{proj.title}</h4>
                        {proj.link && <a href={proj.link} className="text-sm text-slate-400 hover:text-orange-500">visit live &rarr;</a>}
                      </div>
                      <p className="text-slate-600 mb-2">{proj.description}</p>
                      <div className="flex gap-2 text-sm text-orange-600/80 font-mono">
                        {proj.techStack?.split(',').map((t, i) => <span key={i}>#{t.trim()}</span>)}
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="text-lg font-bold text-slate-900 uppercase tracking-widest border-b-2 border-orange-200 pb-2 mb-6">
                  Professional Journey
                </h3>
                <div className="border-l-2 border-orange-100 pl-6 space-y-8">
                  {experiences.map(exp => (
                    <div key={exp.id} className="relative">
                      <span className="absolute -left-[31px] top-1.5 w-3 h-3 bg-orange-500 rounded-full border-2 border-white"></span>
                      <h4 className="text-lg font-bold text-slate-800">{exp.role}</h4>
                      <div className="text-orange-600 text-sm mb-2">{exp.company} | {exp.duration}</div>
                      <p className="text-slate-600 text-sm">{exp.description}</p>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            {/* Right Sidebar */}
            <div className="col-span-1 space-y-10 pt-4">
              <section className="bg-orange-50 p-6 rounded-2xl">
                <h3 className="font-bold text-slate-900 mb-4">Contact</h3>
                <div className="space-y-3 text-sm text-slate-600">
                  {email && <div className="flex items-center gap-2"><Mail size={14} className="text-orange-500"/> {email}</div>}
                  {phone && <div className="flex items-center gap-2"><Phone size={14} className="text-orange-500"/> {phone}</div>}
                  {city && <div className="flex items-center gap-2"><MapPin size={14} className="text-orange-500"/> {city}</div>}
                  {socialLinks.map(s => (
                    <div key={s.id} className="flex items-center gap-2"><Globe size={14} className="text-orange-500"/> {s.url}</div>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="font-bold text-slate-900 mb-4 border-b border-orange-200 pb-2">Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {skills.split(',').map((s, i) => (
                    <span key={i} className="px-3 py-1 bg-white border border-slate-200 rounded text-sm text-slate-700 shadow-sm">
                      {s.trim()}
                    </span>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="font-bold text-slate-900 mb-4 border-b border-orange-200 pb-2">Education</h3>
                <div className="space-y-4">
                  {educations.map(edu => (
                    <div key={edu.id}>
                      <div className="font-medium text-slate-800">{edu.degree}</div>
                      <div className="text-sm text-slate-500">{edu.institution}</div>
                      <div className="text-xs text-orange-500">{edu.year}</div>
                    </div>
                  ))}
                </div>
              </section>

               <section>
                <h3 className="font-bold text-slate-900 mb-4 border-b border-orange-200 pb-2">Languages</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{languages}</p>
              </section>
            </div>
          </div>
       </div>
    </div>
  );
};
