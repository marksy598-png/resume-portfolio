import { useState } from 'react';
import { ResumeForm } from './ResumeForm';
import { PortfolioPreview } from './PortfolioPreview';
import { initialResumeData, ResumeData } from '../types';
import { ArrowLeft, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const PortfolioPage = () => {
  const [resumeData, setResumeData] = useState<ResumeData>({
      ...initialResumeData,
      themeColor: '#FF9933' // Default Saffron
  });
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-orange-50 font-serif text-slate-900">
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-orange-200 sticky top-0 z-50 print:hidden shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <button onClick={() => navigate('/')} className="p-2 hover:bg-orange-50 rounded-full transition-colors text-orange-800" title="Back to Home">
                <ArrowLeft className="w-5 h-5" />
             </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-lg">
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-600 to-red-700 tracking-wide">
                Divine Portfolio
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Editor Section */}
          <div className="space-y-6 print:hidden">
            <div className="bg-orange-100 border border-orange-200 rounded-lg p-4 text-orange-900 text-sm">
               <p className="font-semibold italic">"Craft a portfolio that echoes through time."</p>
               <p className="mt-1">Use the editor below to build your divine presence.</p>
            </div>
            
            <ResumeForm data={resumeData} updateData={setResumeData} mode="portfolio" />
          </div>

          {/* Preview Section */}
          <div className="lg:sticky lg:top-24 h-fit print:w-full print:absolute print:top-0 print:left-0 print:m-0">
            <div className="mb-4 lg:hidden print:hidden">
              <h2 className="text-xl font-bold text-orange-900">Preview</h2>
            </div>
            <div className="print:w-full shadow-2xl rounded-xl overflow-hidden bg-white">
              <PortfolioPreview data={resumeData} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
