import React from 'react';
import { ResumeData } from '../../types';

export const MinimalistTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  const { themeColor } = data;

  return (
    <div className="bg-white p-12 min-h-[1100px] font-serif text-slate-800">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-normal tracking-wide mb-3">{data.fullName}</h1>
        <p className="text-lg text-slate-500 tracking-widest uppercase text-xs mb-6">{data.title}</p>
        
        <div className="flex justify-center gap-4 text-sm text-slate-500 italic">
          {data.email && <span>{data.email}</span>}
          {data.email && data.phone && <span>•</span>}
          {data.phone && <span>{data.phone}</span>}
          {data.phone && data.city && <span>•</span>}
          {data.city && <span>{data.city}</span>}
        </div>
        
        {data.socialLinks.length > 0 && (
          <div className="flex justify-center gap-4 mt-2 text-xs text-slate-400">
            {data.socialLinks.map(soc => (
              <a key={soc.id} href={soc.url} className="hover:text-slate-600 underline decoration-slate-300">{soc.platform}</a>
            ))}
          </div>
        )}
      </header>

      <div className="max-w-2xl mx-auto space-y-10">
        {data.careerObjective && (
          <section>
            <p className="text-center text-slate-600 leading-relaxed italic border-l-2 pl-4" style={{ borderColor: themeColor }}>
              "{data.careerObjective}"
            </p>
          </section>
        )}

        {data.experiences.length > 0 && (
          <section>
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-center border-b pb-2">Experience</h3>
            <div className="space-y-8">
              {data.experiences.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline mb-2">
                    <h4 className="font-bold text-lg">{exp.role}</h4>
                    <span className="text-sm text-slate-500 italic">{exp.duration}</span>
                  </div>
                  <div className="text-slate-600 font-medium mb-2">{exp.company}</div>
                  <p className="text-sm text-slate-600 leading-relaxed">{exp.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.projects.length > 0 && (
          <section>
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-center border-b pb-2">Selected Projects</h3>
            <div className="grid grid-cols-1 gap-6">
              {data.projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline mb-1">
                    <h4 className="font-bold">{proj.title}</h4>
                    {proj.link && <a href={proj.link} className="text-xs text-slate-400 hover:text-slate-600">Link ↗</a>}
                  </div>
                  {proj.techStack && <div className="text-xs text-slate-400 mb-2 uppercase tracking-wider">{proj.techStack}</div>}
                  <p className="text-sm text-slate-600 leading-relaxed">{proj.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.educations.length > 0 && (
          <section>
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-center border-b pb-2">Education</h3>
            <div className="space-y-4">
              {data.educations.map((edu) => (
                <div key={edu.id} className="flex justify-between items-end">
                  <div>
                    <div className="font-bold">{edu.degree}</div>
                    <div className="text-sm text-slate-600 italic">{edu.institution}</div>
                  </div>
                  <div className="text-sm text-slate-500">{edu.year}</div>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.skills && (
          <section className="text-center">
            <h3 className="text-sm font-bold uppercase tracking-widest mb-4">Core Skills</h3>
            <p className="text-sm text-slate-600 leading-loose">{data.skills.split(',').join(' • ')}</p>
          </section>
        )}
      </div>
    </div>
  );
};
