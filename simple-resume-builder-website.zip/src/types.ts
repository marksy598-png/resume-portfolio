export type TemplateType = 'classic' | 'modern' | 'minimalist' | 'portfolio';
export type PortfolioTemplate = 'divine_scroll' | 'royal_grid' | 'modern_saffron';

export interface Education {
  id: string;
  degree: string;
  institution: string;
  year: string;
  grade: string;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  duration: string;
  description: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  link?: string;
  techStack?: string;
}

export interface SocialLink {
  id: string;
  platform: string;
  url: string;
}

export interface ResumeData {
  template: TemplateType;
  portfolioTemplate: PortfolioTemplate;
  themeColor: string;
  fullName: string;
  title: string; // Job Title
  phone: string;
  email: string;
  city: string;
  socialLinks: SocialLink[];
  careerObjective: string; // or About Me
  skills: string;
  educations: Education[];
  certifications: string;
  projects: Project[];
  experiences: Experience[];
  achievements: string;
  languages: string;
  personalDetails: {
    dob: string;
    gender: string;
    nationality: string;
    maritalStatus: string;
  };
}

export const initialResumeData: ResumeData = {
  template: 'modern',
  portfolioTemplate: 'divine_scroll',
  themeColor: '#FF9933', // Saffron default
  fullName: "",
  title: "",
  phone: "",
  email: "",
  city: "",
  socialLinks: [],
  careerObjective: "",
  skills: "",
  educations: [
    { id: "1", degree: "", institution: "", year: "", grade: "" }
  ],
  certifications: "",
  projects: [],
  experiences: [],
  achievements: "",
  languages: "",
  personalDetails: {
    dob: "",
    gender: "",
    nationality: "",
    maritalStatus: "",
  },
};
