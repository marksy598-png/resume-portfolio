import React from 'react';
import { ResumeData } from '../../types';
import { Phone, Mail, MapPin } from 'lucide-react';

export const ClassicTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  const { themeColor } = data;
  
  return (
    <div className="bg-white p-8 shadow-sm min-h-[1100px]">
      <header className="text-center border-b-2 pb-4 mb-6" style={{ borderColor: themeColor }}>
        <h1 className="text-3xl font-bold uppercase tracking-wider mb-2" style={{ color: '#1a202c' }}>
          {data.fullName}
        </h1>
        {data.title && <p className="text-xl font-medium text-gray-600 mb-2">{data.title}</p>}
        
        <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-600">
          {data.phone && <div className="flex items-center gap-1"><Phone className="w-4 h-4" />{data.phone}</div>}
          {data.email && <div className="flex items-center gap-1"><Mail className="w-4 h-4" />{data.email}</div>}
          {data.city && <div className="flex items-center gap-1"><MapPin className="w-4 h-4" />{data.city}</div>}
        </div>
      </header>

      <div className="space-y-6">
        {data.careerObjective && (
          <section>
            <h2 className="text-lg font-bold border-b mb-3 uppercase flex items-center gap-2" style={{ color: themeColor, borderColor: '#e2e8f0' }}>
              Summary
            </h2>
            <p className="text-gray-700 text-sm leading-relaxed">{data.careerObjective}</p>
          </section>
        )}

        {data.experiences.length > 0 && (
          <section>
            <h2 className="text-lg font-bold border-b mb-3 uppercase" style={{ color: themeColor, borderColor: '#e2e8f0' }}>Experience</h2>
            <div className="space-y-4">
              {data.experiences.map((exp) => (
                <div key={exp.id} className="text-sm">
                  <div className="flex justify-between font-bold text-gray-800">
                    <span>{exp.role}</span>
                    <span className="text-gray-600 font-normal">{exp.duration}</span>
                  </div>
                  <div className="font-semibold text-gray-700 mb-1">{exp.company}</div>
                  <p className="text-gray-600 whitespace-pre-line">{exp.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.projects.length > 0 && (
          <section>
            <h2 className="text-lg font-bold border-b mb-3 uppercase" style={{ color: themeColor, borderColor: '#e2e8f0' }}>Projects</h2>
            <div className="space-y-4">
              {data.projects.map((proj) => (
                <div key={proj.id} className="text-sm">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-bold text-gray-800">{proj.title}</span>
                    {proj.link && <a href={proj.link} className="text-blue-600 hover:underline text-xs">{proj.link}</a>}
                  </div>
                  {proj.techStack && <div className="text-xs text-gray-500 mb-1 italic">{proj.techStack}</div>}
                  <p className="text-gray-600 leading-relaxed whitespace-pre-line">{proj.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.educations.length > 0 && (
          <section>
            <h2 className="text-lg font-bold border-b mb-3 uppercase" style={{ color: themeColor, borderColor: '#e2e8f0' }}>Education</h2>
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="text-gray-600 border-b border-gray-100">
                  <th className="py-2 font-semibold">Degree</th>
                  <th className="py-2 font-semibold">Institution</th>
                  <th className="py-2 font-semibold">Year</th>
                  <th className="py-2 font-semibold text-right">Grade</th>
                </tr>
              </thead>
              <tbody className="text-gray-700">
                {data.educations.map((edu) => (
                  <tr key={edu.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-2 font-medium">{edu.degree}</td>
                    <td className="py-2">{edu.institution}</td>
                    <td className="py-2">{edu.year}</td>
                    <td className="py-2 text-right">{edu.grade}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        )}

        {data.skills && (
          <section>
            <h2 className="text-lg font-bold border-b mb-3 uppercase" style={{ color: themeColor, borderColor: '#e2e8f0' }}>Skills</h2>
            <p className="text-sm text-gray-700 leading-relaxed">{data.skills}</p>
          </section>
        )}
      </div>
    </div>
  );
};
