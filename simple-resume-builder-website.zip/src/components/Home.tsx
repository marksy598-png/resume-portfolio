import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Briefcase, Star, Sparkles } from 'lucide-react';

const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100 flex flex-col items-center justify-center p-6 font-serif">
      <div className="max-w-4xl w-full text-center space-y-12">
        
        {/* Header Section */}
        <div className="space-y-4 animate-fade-in-down">
          <div className="flex items-center justify-center space-x-3 text-orange-600 mb-6">
            <Sparkles className="w-8 h-8" />
            <span className="text-xl font-semibold tracking-widest uppercase">Divine Builder</span>
            <Sparkles className="w-8 h-8" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600 drop-shadow-sm">
            Craft Your Legacy
          </h1>
          <p className="text-xl text-orange-800/80 max-w-2xl mx-auto italic">
            "Build a resume that speaks your worth and a portfolio that showcases your brilliance."
          </p>
        </div>

        {/* Selection Cards */}
        <div className="grid md:grid-cols-2 gap-8 w-full max-w-3xl mx-auto mt-12">
          
          {/* Resume Card */}
          <button 
            onClick={() => navigate('/resume')}
            className="group relative bg-white p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 border-2 border-orange-100 hover:border-orange-300 text-left overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center text-orange-600 mb-6 group-hover:bg-orange-600 group-hover:text-white transition-colors">
                <FileText className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2 group-hover:text-orange-600 transition-colors">Build Resume</h2>
              <p className="text-gray-500 group-hover:text-gray-600">
                Create a professional resume with standard formats and classic layouts.
              </p>
            </div>
          </button>

          {/* Portfolio Card */}
          <button 
            onClick={() => navigate('/portfolio')}
            className="group relative bg-gradient-to-br from-orange-600 to-red-700 p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 border-2 border-transparent text-left overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center text-white mb-6 group-hover:bg-white group-hover:text-orange-600 transition-colors">
                <Briefcase className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Build Portfolio</h2>
              <p className="text-orange-100 group-hover:text-white">
                Design a stunning portfolio with divine templates and rich visuals.
              </p>
            </div>
          </button>
        </div>

        {/* Footer Decoration */}
        <div className="pt-12 text-orange-300/60 flex items-center justify-center space-x-2">
           <Star className="w-4 h-4" />
           <div className="h-px w-24 bg-orange-200" />
           <Star className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};

export default Home;
