import React from 'react';
import { ResumeData } from '../../types';
import { ExternalLink, Mail, MapPin, Smartphone } from 'lucide-react';

export const PortfolioTemplate: React.FC<{ data: ResumeData }> = ({ data }) => {
  const { themeColor } = data;

  return (
    <div className="bg-slate-900 text-slate-200 min-h-[1100px] p-8 font-sans">
      {/* Hero Section */}
      <header className="py-12 border-b border-slate-800">
        <div className="max-w-3xl">
          <p className="text-xl font-medium mb-2" style={{ color: themeColor }}>Hello, I'm</p>
          <h1 className="text-6xl font-bold text-white mb-4 tracking-tight">{data.fullName}</h1>
          <h2 className="text-3xl text-slate-400 mb-8">{data.title}</h2>
          
          <div className="flex flex-wrap gap-6 text-sm">
            {data.email && <div className="flex items-center gap-2"><Mail className="w-4 h-4" />{data.email}</div>}
            {data.phone && <div className="flex items-center gap-2"><Smartphone className="w-4 h-4" />{data.phone}</div>}
            {data.city && <div className="flex items-center gap-2"><MapPin className="w-4 h-4" />{data.city}</div>}
          </div>
          
          <div className="flex gap-4 mt-8">
            {data.socialLinks.map(soc => (
              <a key={soc.id} href={soc.url} className="px-4 py-2 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors flex items-center gap-2 text-sm font-medium">
                {soc.platform} <ExternalLink className="w-3 h-3" />
              </a>
            ))}
          </div>
        </div>
      </header>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-12 py-12">
        
        {/* Left Col - Projects */}
        <div className="md:col-span-8 space-y-12">
          {data.careerObjective && (
            <section>
              <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-4">About Me</h3>
              <p className="text-lg text-slate-300 leading-relaxed">{data.careerObjective}</p>
            </section>
          )}

          <section>
            <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6">Featured Projects</h3>
            <div className="grid grid-cols-1 gap-6">
              {data.projects.map((proj) => (
                <div key={proj.id} className="bg-slate-800 rounded-xl p-6 border border-slate-700 hover:border-slate-600 transition-colors">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="text-xl font-bold text-white">{proj.title}</h4>
                    {proj.link && (
                      <a href={proj.link} className="text-slate-400 hover:text-white">
                        <ExternalLink className="w-5 h-5" />
                      </a>
                    )}
                  </div>
                  <p className="text-slate-400 mb-4">{proj.description}</p>
                  {proj.techStack && (
                    <div className="flex flex-wrap gap-2">
                      {proj.techStack.split(',').map((tech, i) => (
                        <span key={i} className="px-2 py-1 bg-slate-900 rounded text-xs text-slate-300 border border-slate-700">
                          {tech.trim()}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          <section>
             <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6">Experience</h3>
             <div className="space-y-8">
               {data.experiences.map((exp) => (
                 <div key={exp.id} className="border-l-2 pl-6 space-y-2" style={{ borderColor: themeColor }}>
                   <div className="flex justify-between text-white">
                     <h4 className="font-bold text-lg">{exp.role}</h4>
                     <span className="text-sm text-slate-500">{exp.duration}</span>
                   </div>
                   <div className="text-slate-400">{exp.company}</div>
                   <p className="text-slate-500 text-sm">{exp.description}</p>
                 </div>
               ))}
             </div>
          </section>
        </div>

        {/* Right Col - Info */}
        <div className="md:col-span-4 space-y-10">
          {data.skills && (
            <section>
              <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-4">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {data.skills.split(',').map((skill, i) => (
                  <span key={i} className="px-3 py-1 bg-slate-800 rounded-full text-sm text-slate-300">
                    {skill.trim()}
                  </span>
                ))}
              </div>
            </section>
          )}

          {data.educations.length > 0 && (
            <section>
              <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-4">Education</h3>
              <div className="space-y-6">
                {data.educations.map((edu) => (
                  <div key={edu.id} className="bg-slate-800/50 p-4 rounded-lg">
                    <div className="font-bold text-white">{edu.degree}</div>
                    <div className="text-slate-400 text-sm">{edu.institution}</div>
                    <div className="flex justify-between mt-2 text-xs text-slate-500">
                      <span>{edu.year}</span>
                      <span>{edu.grade}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {(data.certifications || data.achievements) && (
            <section className="space-y-8">
              {data.certifications && (
                <div>
                   <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-4">Certifications</h3>
                   <ul className="space-y-2 text-sm text-slate-400">
                     {data.certifications.split('\n').map((c, i) => c.trim() && <li key={i}>• {c}</li>)}
                   </ul>
                </div>
              )}
               {data.achievements && (
                <div>
                   <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-4">Achievements</h3>
                   <ul className="space-y-2 text-sm text-slate-400">
                     {data.achievements.split('\n').map((c, i) => c.trim() && <li key={i}>• {c}</li>)}
                   </ul>
                </div>
              )}
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
